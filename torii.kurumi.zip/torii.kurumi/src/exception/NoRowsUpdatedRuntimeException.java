package exception;


public class NoRowsUpdatedRuntimeException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
